import React from "react";
import Header from "./Header"

function Header() {
  return (
    <header>
      <h1> ShapeAI Bootcamp </h1>
      </header>
    );
}

export default Header;